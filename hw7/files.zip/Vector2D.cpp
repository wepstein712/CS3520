#include "Vector2D.hpp"
#include <stdexcept>

// TODO
