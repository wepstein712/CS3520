#include "words.hpp"
#include <cstring>
#include <iostream>



Words *
newListFromSize(unsigned int max_words)
{
  // TODO
  return nullptr;
}

Words *
newListFromString(const char *words)
{
  // TODO
  return nullptr;
}

int
deleteList(Words *p_w)
{
  // TODO
  return -1;
}

int
printList(Words *p_w)
{
  // TODO
  return -1;
}

int
appendListFromString(Words *p_w, const char *words)
{
  // TODO
  return -1;
}

int
appendListFromList(Words *dst, const Words *src)
{
  // TODO
  return -1;
}

const char *
findWord(const Words *p_w, const char *word)
{
  // TODO
  return nullptr;
}

int
removeWord(Words *p_w, const char *word)
{
  // TODO
  return -1;
}
