#include <cxxtest/Flags.h>

#ifdef _CXXTEST_PARTIAL_TEMPLATE_SPECIALIZATION
int main() { return 0; }
#endif // !_CXXTEST_PARTIAL_TEMPLATE_SPECIALIZATION

