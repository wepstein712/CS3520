/**
 * \file
 * File containing a class
 */
/****************************************************
 * Author: Edmundo LOPEZ
 * email:  lopezed5@etu.unige.ch
 *
 * **************************************************/

class Hello
  {
    public:
      int foo(int x, int y);
  };
