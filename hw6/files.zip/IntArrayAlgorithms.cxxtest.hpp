#ifndef INT_ARRAY_ALGORITHMS_CXXTEST_H
#define INT_ARRAY_ALGORITHMS_CXXTEST_H

#include <cxxtest/TestSuite.h>
#include <iostream>
#include "IntArrayAlgorithms.hpp"

class IntArrayAlgorithmsTestSuite : public CxxTest::TestSuite
{
public:

  // TODO
  void test_REMOVEME() {}

};

#endif
