#include "IntArrayAlgorithms.hpp"
#include "IntArray.hpp"

void IntArrayAlgorithms::swap(IntArray & lhs, IntArray & rhs) {
  // TODO
}

bool IntArrayAlgorithms::contains(const IntArray & arr, int val) {
  // TODO
  return false;
}

void IntArrayAlgorithms::sort(IntArray & arr) {
  // TODO
}

int IntArrayAlgorithms::sum(const IntArray & arr) {
  // TODO
  return 0;
}

int IntArrayAlgorithms::product(const IntArray & arr) {
  // TODO
  return 1;
}
