#include <iostream>

int
main()
{
  // TODO

  return 0;
}
