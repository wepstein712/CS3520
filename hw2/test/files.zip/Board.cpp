#include "Board.h"
#include <iostream>

Board::Board()
{
  // TODO ?
}

Board::~Board()
{
  // TODO ?
}

void Board::reset_board_size(unsigned int size)
{
  // TODO
}

bool Board::make_move(unsigned int row, unsigned int column)
{
  // TODO
  return true;
}

GameStatus Board::get_status() const
{
  // TODO
  return GameStatus::OVER_TIE;
}

void Board::print_board() const
{
  // TODO
}
