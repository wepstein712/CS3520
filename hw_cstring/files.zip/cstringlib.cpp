#include "cstringlib.hpp"

namespace str {
  
  size_t strlen(const char *str) {
    // TODO
    return 0;
  }
  
  char *strncpy(char *destination, const char *source, size_t num) {
    // TODO
    return nullptr;
  }

  char *strncat(char *destination, const char *source, size_t num) {
    // TODO
    return nullptr;
  }

  int strcmp(const char *str1, const char *str2) {
    // TODO
    return 0;
  }

  const char *strchr(const char *str, int character) {
    // TODO
    return nullptr;
  }

  const char *strrchr(const char *str, int character) {
    // TODO
    return nullptr;
  }

  const char *strstr(const char *str1, const char *str2) {
    // TODO
    return nullptr;
  }

  size_t strspn(const char *str1, const char *str2) {
    // TODO
    return 0;
  }

  size_t strcspn(const char *str1, const char *str2) {
    // TODO
    return 0;
  }

  char *strtok(char * str, const char * delimiters) {
    // TODO
    return nullptr;
  }

}
