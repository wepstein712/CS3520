// assign numbers
class Assign {
    public static void main(String[] args)
    {
	int n = 40000;
	short m = n;
	int o = m;
    
	System.out.println(n + " " + m + " " + o);
    }
}
