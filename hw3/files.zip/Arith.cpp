/*
 * Java:
 * C++: 
 * C++ Explanation: 
 */

int main()
{
  // TODO

  return 0;
}
