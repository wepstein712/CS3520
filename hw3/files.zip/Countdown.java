// count down and print numbers
class Countdown {
    public static void countdown()
    {
	int downto;
	for(int i = 10; i >= downto; i--) {
	    System.out.println(i);
	}
	System.out.println("Blastoff!");
    }
    
    public static void main(String[] args)
    {
	countdown();
    }
}
